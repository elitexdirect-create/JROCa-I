const SYSTEM = `You are JROC — the AI operating intelligence layer of J-ROC OS.
Mission: help an entrepreneur jumpstart revenue, optimize operations, and convert more opportunities.
You operate across CRM, sales, marketing, finance, operations, AI agents, automations, proposals and business strategy.
Be direct, practical and opinionated. Use the supplied workspace context when useful. Never fabricate workspace facts.
For legal, tax or regulated matters, give general education and flag professional review.
Do not claim you performed actions unless the system actually performed them.
Keep responses tight and actionable.`;

export default async (req) => {
  if (req.method !== "POST") return new Response(JSON.stringify({error:"Method not allowed"}), {status:405,headers:{"Content-Type":"application/json"}});
  try {
    const key = process.env.ANTHROPIC_API_KEY;
    if (!key) return new Response(JSON.stringify({error:"ANTHROPIC_API_KEY is not configured."}), {status:500,headers:{"Content-Type":"application/json"}});
    const {message,context} = await req.json();
    const prompt = `${message}\n\nWORKSPACE CONTEXT:\n${JSON.stringify(context||{},null,2)}`;
    const r = await fetch("https://api.anthropic.com/v1/messages",{
      method:"POST",
      headers:{"Content-Type":"application/json","x-api-key":key,"anthropic-version":"2023-06-01"},
      body:JSON.stringify({model:"claude-sonnet-4-6",max_tokens:1200,system:SYSTEM,messages:[{role:"user",content:prompt}]})
    });
    const data=await r.json();
    if(!r.ok) return new Response(JSON.stringify({error:data?.error?.message||"AI provider error"}),{status:502,headers:{"Content-Type":"application/json"}});
    const reply=(data.content||[]).filter(x=>x.type==="text").map(x=>x.text).join("\n\n")||"JROC had no response.";
    return new Response(JSON.stringify({reply}),{status:200,headers:{"Content-Type":"application/json"}});
  } catch(e) {
    return new Response(JSON.stringify({error:"Internal comm failure."}),{status:500,headers:{"Content-Type":"application/json"}});
  }
};