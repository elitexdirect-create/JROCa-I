# J-ROC OS v1

A first production-oriented foundation for J-ROC OS.

## Included
- Supabase authentication
- Organization/workspace creation
- Organization-scoped CRM
- Leads
- Revenue pipeline
- Tasks
- AI Agents registry
- Automations foundation
- Proposals foundation
- Ask JROC command center
- Server-side Anthropic function

## Supabase
Project URL:
https://wuuwlebhidikusagstvw.supabase.co

The frontend uses a Supabase publishable key. This key is safe for browser use when RLS is correctly configured.

## Environment
For the Netlify function set:
`ANTHROPIC_API_KEY`

## Deploy
Upload this folder to Netlify or connect the repository. The function lives at:
`netlify/functions/chat.js`

## Important
Existing legacy leads in the database that do not have an organization_id are intentionally not surfaced by the new RLS model. They should be reviewed and assigned to an organization through an authenticated admin/data migration workflow.
